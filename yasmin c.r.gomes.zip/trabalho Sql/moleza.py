import sqlite3
    

class mycrud:

    def __init__(self,banco):
        self.conn = sqlite3.connect(banco)
        self.cursor = self.conn.cursor()
        print("Banco criado com sucesso!!!!!")

    def encerrar(self):
        self.conn.close()
        print("fim da operacao")

    def criar_tabela(self):
        sql= '''
        CREATE TABLE IF NOT EXISTS PESSOAS(
            id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf VARCHAR(11) NOT NULL
        );
     '''
        self.cursor.execute(sql)
        print("tabela criada")

    def adicionar(self, id, nome, cpf):
        self.cursor.execute("INSERT INTO PESSOAS (id, nome, cpf) VALUES (?,?,?)", (id, nome, cpf))

        self.conn.commit()

        self.cursor.execute("SELECT * FROM PESSOAS;")
        print("==========================================\n")

        for linha in self.cursor.fetchall():
            print(f'{linha}')


    
    def ler(self, id):
        self.cursor.execute("SELECT id, nome, cpf FROM PESSOAS WHERE id = ?", (id))
        print("==========================================\n")
        for linha in self.cursor.fetchall():
            print(linha)


    # Metodo para alterar
    def alterar(self, id, nome, cpf):

        self.cursor.execute("UPDATE PESSOAS SET nome = ?, cpf = ? WHERE id = ? ", (nome, cpf, id)) #comando sql para alte cID
        self.conn.commit()
        print("==========================================\n")
        print(f"Registro {id} alterado com sucesso")


    # Metodo para excluir usuário
    def excluir(self, id):

        self.cursor.execute("DELETE FROM PESSOAS WHERE id = ? ", (id))
        self.conn.commit() #comando sql para deletar o usuario com base no ID
        print("==========================================\n")
        print(f"Registro {id} exlcuido com sucesso")